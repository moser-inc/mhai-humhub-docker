<?php
return array (
  'Ask' => 'Opýtať sa',
);
