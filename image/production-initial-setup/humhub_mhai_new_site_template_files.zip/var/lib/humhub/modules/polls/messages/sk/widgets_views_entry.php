<?php
return array (
  '<strong>Note:</strong> The result is hidden until the poll is closed by a moderator.' => '<strong>Poznámka:</strong> Výsledok je skrytý, kým anketu neuzavrie moderátor.',
  'Anonymous' => 'Anonymný',
  'Closed' => 'ZATVORENÉ',
  'Complete Poll' => 'Vyplňte anketu',
  'Reopen Poll' => 'Znovu otvoriť anketu',
  'Reset my vote' => 'Obnoviť moje hlasovanie',
  'Vote' => 'Hlasujte',
  'and {count} more vote for this.' => 'a ďalší ({count}) za to hlasujú.',
  'votes' => 'hlasov',
);
