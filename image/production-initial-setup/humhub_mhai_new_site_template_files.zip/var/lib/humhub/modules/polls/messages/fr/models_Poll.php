<?php
return array (
  'Answers' => 'Réponses',
  'Description' => 'Description',
  'Multiple answers per user' => 'Réponses multiples par utilisateur',
  'Please specify at least {min} answers!' => 'Merci de spécifier au moins {min} réponses.',
  'Poll' => 'Sondage',
  'Question' => 'Question',
);
