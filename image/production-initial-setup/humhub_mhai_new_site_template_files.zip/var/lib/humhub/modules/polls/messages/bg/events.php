<?php
return array (
  'Again? ;Weary;' => 'Отново? ;Weary;',
  'Club A Steakhouse' => 'Club A Steakhouse',
  'Location of the next meeting' => 'Място на следващата среща',
  'Pisillo Italian Panini' => 'Pisillo Italian Panini',
  'Right now, we are in the planning stages for our next meetup and we would like to know from you, where you would like to go?' => 'В момента сме в етап на планиране за следващата ни среща и бихме искали да знаем от вас къде бихте искали да отидем?',
  'To Daniel' => 'На Даниел',
  'Why don\'t we go to Bemelmans Bar?' => 'Защо не отидем в бар Bemelmans?',
);
