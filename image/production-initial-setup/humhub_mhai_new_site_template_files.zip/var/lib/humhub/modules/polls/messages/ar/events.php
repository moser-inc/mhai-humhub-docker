<?php
return array (
  'Again? ;Weary;' => 'مرة أخرى؟ ؛المرهق؛',
  'Club A Steakhouse' => 'نادي ستيك هاوس',
  'Location of the next meeting' => 'مكان اللقاء القادم',
  'Pisillo Italian Panini' => 'بانيني إيطالي صغير',
  'Right now, we are in the planning stages for our next meetup and we would like to know from you, where you would like to go?' => 'نحن الآن في مراحل التخطيط للقائنا القادم ونود أن نعرف منك، إلى أين تريد أن تذهب؟',
  'To Daniel' => 'إلى دانيال',
  'Why don\'t we go to Bemelmans Bar?' => 'لماذا لا نذهب إلى  Bemelmans?',
);
