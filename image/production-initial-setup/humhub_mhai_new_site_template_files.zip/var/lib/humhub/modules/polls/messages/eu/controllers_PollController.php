<?php
return array (
  'Access denied!' => 'Sarrera debekatua!',
  'Anonymous poll!' => 'Inkesta anonimoa!',
  'Could not load poll!' => 'Ezin izan da inkesta kargatu!',
  'Invalid answer!' => 'Erantzun baliogabea!',
  'Users voted for: <strong>{answer}</strong>' => 'Erabiltzaileek ondorengoa bozkatu dute: <strong>{answer}</strong>',
  'Voting for multiple answers is disabled!' => 'Erantzun anitzeko botoa desgaituta dago!',
  'You have insufficient permissions to perform that operation!' => 'Ez duzu baimen nahikorik eragiketa hori egiteko!',
);
