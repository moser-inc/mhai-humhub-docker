<?php
return array (
  'Access denied!' => 'Acesso negado!',
  'Anonymous poll!' => 'Votação anónima!',
  'Could not load poll!' => 'Não conseguimos carregar a votação!',
  'Invalid answer!' => 'Resposta não válida!',
  'Users voted for: <strong>{answer}</strong>' => 'Votou-se: <strong>{answer}</strong>',
  'Voting for multiple answers is disabled!' => 'Votação aberta a várias opções desactivada!',
  'You have insufficient permissions to perform that operation!' => 'Não tens permissões suficientes para executar esta operação!',
);
