<?php
return array (
  '<b>There are no polls yet!</b>' => '<b>Все още няма анкети!</b>',
  '<b>There are no polls yet!</b><br>Be the first and create one...' => '<b>Все още няма анкети!</b>Бъдете първият и създайте такава...',
  'Asked by me' => 'Направени от мен',
  'No answered yet' => 'Все още няма отговор',
  'Only private polls' => 'Само частни анкети',
  'Only public polls' => 'Само обществени анкети',
);
