<?php
return array (
  '{userName} created a new {question}.' => 'قام {userName} بإنشاء  {question}جديد.',
);
