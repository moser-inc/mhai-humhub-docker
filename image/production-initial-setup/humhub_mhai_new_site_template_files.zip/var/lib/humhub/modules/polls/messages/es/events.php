<?php
return array (
  'Again? ;Weary;' => '¿De nuevo? ;Cansado;',
  'Club A Steakhouse' => 'Restaurante especializado en cortes de carne',
  'Location of the next meeting' => 'Lugar de la próxima reunión',
  'Pisillo Italian Panini' => 'Pisillo Italian Panini',
  'Right now, we are in the planning stages for our next meetup and we would like to know from you, where you would like to go?' => 'Ahora mismo, estamos en las etapas de planificación para nuestra próxima reunión y nos gustaría saber de usted, a dónde te gustaría ir?',
  'To Daniel' => 'Para Daniel',
  'Why don\'t we go to Bemelmans Bar?' => '¿Por qué no vamos al Bar Bemelmans?',
);
