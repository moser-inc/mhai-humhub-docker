<?php
return array (
  'Answers' => 'Vastausta',
  'Description' => 'Kuvaus',
  'Multiple answers per user' => 'Useita vastauksia',
  'Please specify at least {min} answers!' => 'Vastaa edes vähintään {min} kysymykseen!',
  'Poll' => 'Kysymys',
  'Question' => 'Kysymys',
);
