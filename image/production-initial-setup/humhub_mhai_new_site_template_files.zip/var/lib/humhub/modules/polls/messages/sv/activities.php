<?php
return array (
  'Polls' => 'Enkät',
  'Whenever someone participates in a poll.' => 'När någon deltar i en enkät.',
);
