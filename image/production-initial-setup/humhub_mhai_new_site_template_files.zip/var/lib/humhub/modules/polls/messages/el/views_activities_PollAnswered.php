<?php
return array (
  '{userName} answered the {question}.' => 'Ο/Η {userName} απάντησε την {question}.',
);
