<?php
return array (
  'Polls' => 'Ankete',
  'Whenever someone participates in a poll.' => '',
);
