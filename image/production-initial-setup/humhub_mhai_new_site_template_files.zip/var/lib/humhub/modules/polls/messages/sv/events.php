<?php
return array (
  'Again? ;Weary;' => 'Om igen? ;Trötta;',
  'Club A Steakhouse' => 'Club A Steakhouse',
  'Location of the next meeting' => 'Plats för nästa möte',
  'Pisillo Italian Panini' => 'Pisillo italienska Panini',
  'Right now, we are in the planning stages for our next meetup and we would like to know from you, where you would like to go?' => 'Just nu är vi i planeringsstadiet för vår nästa träff och vi skulle vilja veta vart du skulle vilja åka?',
  'To Daniel' => 'Till Daniel',
  'Why don\'t we go to Bemelmans Bar?' => 'Varför går vi inte till Bemelmans Bar?',
);
