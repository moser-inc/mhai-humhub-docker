<?php
return array (
  'Add answer...' => 'Añadir respuesta...',
  'Anonymous Votes?' => '¿Votos Anónimos?',
  'Description' => 'Descripción',
  'Display answers in random order?' => '¿Mostrar respuestas en orden aleatorio?',
  'Edit answer (empty answers will be removed)...' => 'Editar respuesta (las respuestas vacías se eliminarán) ...',
  'Edit your poll question...' => 'Editar la pregunta de la encuesta ...',
  'Hide results until poll is closed?' => '¿Ocultar resultados hasta que se cierre la encuesta?',
  'Question' => 'Pregunta',
);
