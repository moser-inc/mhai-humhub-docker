<?php
return array (
  'Allows the user to create polls' => 'Sta de gebruiker toe stembussen maken',
  'Allows to start polls.' => 'Starten van stembussen toestaan.',
  'Answers' => 'Antwoorden',
  'At least one answer is required' => 'Ten minste één antwoord is vereist',
  'Cancel' => 'Annuleer',
  'Create poll' => 'Maak een stembus',
  'Polls' => 'Stembus',
  'Save' => 'Bewaar',
  '{n,plural,=1{# {htmlTagBegin}vote{htmlTagEnd}}other{# {htmlTagBegin}votes{htmlTagEnd}}}' => '{n,plural,=1{# {htmlTagBegin}stem{htmlTagEnd}}other{# {htmlTagBegin}stemmen{htmlTagEnd}}}',
);
