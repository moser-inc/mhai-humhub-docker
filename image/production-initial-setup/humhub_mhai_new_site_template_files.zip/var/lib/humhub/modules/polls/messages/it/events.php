<?php
return array (
  'Again? ;Weary;' => 'Ancora? ;Weary;',
  'Club A Steakhouse' => 'Paninoteca',
  'Location of the next meeting' => 'Luogo del prossimo incontro',
  'Pisillo Italian Panini' => 'Panini Italiani Pisillo',
  'Right now, we are in the planning stages for our next meetup and we would like to know from you, where you would like to go?' => 'Al momento siamo nella fase di pianificazione per il nostro prossimo incontro, e vorremmo chiederti: dove vorresti andare?',
  'To Daniel' => 'Da Daniele',
  'Why don\'t we go to Bemelmans Bar?' => 'Perché non andiamo al bar Bemelmans?',
);
