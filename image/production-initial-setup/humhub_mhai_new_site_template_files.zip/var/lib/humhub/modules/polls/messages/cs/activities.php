<?php
return array (
  'Polls' => 'Ankety',
  'Whenever someone participates in a poll.' => 'Kdykoli se někdo zúčastní ankety.',
);
