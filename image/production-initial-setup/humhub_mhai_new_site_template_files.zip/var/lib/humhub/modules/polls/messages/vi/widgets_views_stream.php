<?php
return array (
  '<b>There are no polls yet!</b>' => '<b>Chưa có cuộc biểu quyết nào!</b>',
  '<b>There are no polls yet!</b><br>Be the first and create one...' => '<b>Chưa có cuộc biểu quyết nào!</b><br>Hãy là người tạo biểu quyết đầu tiên...',
  'Asked by me' => 'Hỏi bởi tôi',
  'No answered yet' => 'Chưa được trả lời',
  'Only private polls' => 'Chỉ các cuộc biểu quyết riêng tư',
  'Only public polls' => 'Chỉ các cuộc biểu quyết công khai',
);
