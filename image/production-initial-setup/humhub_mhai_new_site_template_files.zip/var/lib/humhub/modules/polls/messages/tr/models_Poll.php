<?php

return [
    'Answers' => 'Cevaplar',
    'Description' => 'Açıklama',
    'Multiple answers per user' => 'Kullanıcılar için çoklu cevap',
    'Please specify at least {min} answers!' => 'Lütfen en az {min} cevap işaretleyin!',
    'Question' => 'Soru',
    'Poll' => '',
];
