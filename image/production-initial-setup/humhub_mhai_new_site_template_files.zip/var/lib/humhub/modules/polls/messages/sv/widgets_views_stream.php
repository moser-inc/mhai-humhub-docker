<?php
return array (
  '<b>There are no polls yet!</b>' => '<strong>Det finns inga undersökningar än!</strong>',
  '<b>There are no polls yet!</b><br>Be the first and create one...' => '<strong>Det finns inga undersökningar än!</strong><br>Bli först och skapa en...',
  'Asked by me' => 'Frågade av mig',
  'No answered yet' => 'Ännu ej besvarade',
  'Only private polls' => 'Endast privata undersökningar',
  'Only public polls' => 'Endast publika undersökningar',
);
