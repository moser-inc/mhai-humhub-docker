<?php
return array (
  'Polls' => 'Anketler',
  'Whenever someone participates in a poll.' => '',
);
