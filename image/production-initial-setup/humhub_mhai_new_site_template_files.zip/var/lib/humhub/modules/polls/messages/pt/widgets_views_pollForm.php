<?php
return array (
  'Add answer...' => 'Adicionar opção...',
  'Anonymous Votes?' => 'Votos anónimos?',
  'Description' => 'Descrição',
  'Display answers in random order?' => 'Ordenar opções aleatoriamente?',
  'Edit answer (empty answers will be removed)...' => 'Editar opção (opções vazias serão removidas)...',
  'Edit your poll question...' => 'Editar questão da votação...',
  'Hide results until poll is closed?' => 'Resultados só divulgados no fim da votação',
  'Question' => 'Questão',
);
