<?php
return array (
  'Access denied!' => '禁止访问',
  'Anonymous poll!' => '匿名投票',
  'Could not load poll!' => '无法加载投票！',
  'Invalid answer!' => '无效的回答!',
  'Users voted for: <strong>{answer}</strong>' => '用户投票: <strong>{answer}</strong>',
  'Voting for multiple answers is disabled!' => '多选已禁用!',
  'You have insufficient permissions to perform that operation!' => '您没有足够的权限执行这个操作!',
);
