<?php
return array (
  '<b>There are no polls yet!</b>' => '<b>Még nincsenek szavazások!</b>',
  '<b>There are no polls yet!</b><br>Be the first and create one...' => '<b>Még nincsenek szavazások!</b><br /> Hozz létre egyet elsőnek!',
  'Asked by me' => 'Én kérdeztem',
  'No answered yet' => 'Még nincs megválaszolva',
  'Only private polls' => 'Csak privát szavazások',
  'Only public polls' => 'Csak nyilvános szavazások',
);
