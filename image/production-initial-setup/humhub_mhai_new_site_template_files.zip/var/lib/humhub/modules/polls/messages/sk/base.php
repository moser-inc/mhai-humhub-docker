<?php
return array (
  'Allows the user to create polls' => 'Umožňuje používateľovi vytvárať ankety',
  'Allows to start polls.' => 'Umožňuje spustiť prieskumy verejnej mienky.',
  'Answers' => 'Odpovede',
  'At least one answer is required' => 'Vyžaduje sa aspoň jedna odpoveď',
  'Cancel' => 'Zrušiť',
  'Create poll' => 'Vytvoriť anketu',
  'Polls' => 'Ankety',
  'Save' => 'Uložiť',
  '{n,plural,=1{# {htmlTagBegin}vote{htmlTagEnd}}other{# {htmlTagBegin}votes{htmlTagEnd}}}' => '',
);
