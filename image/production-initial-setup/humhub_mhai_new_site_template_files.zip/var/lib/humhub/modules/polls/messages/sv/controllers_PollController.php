<?php
return array (
  'Access denied!' => 'Tillträde nekas!',
  'Anonymous poll!' => 'Anonym enkät!',
  'Could not load poll!' => 'Kunde inte ladda enkät!',
  'Invalid answer!' => 'Felaktigt svar!',
  'Users voted for: <strong>{answer}</strong>' => 'Användarna röstade för: <strong>{answer}</strong>',
  'Voting for multiple answers is disabled!' => 'Att rösta på flera alternativ är avstängt!',
  'You have insufficient permissions to perform that operation!' => 'Du har inte tillräckliga rättigheter för att göra detta!',
);
