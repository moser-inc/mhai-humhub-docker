<?php
return array (
  '<strong>Note:</strong> The result is hidden until the poll is closed by a moderator.' => '<strong>Nota:</strong> O resultado está oculto até a votação ser fechada pela moderação.',
  'Anonymous' => 'Anónimo',
  'Closed' => 'Fechada',
  'Complete Poll' => 'Votação completa',
  'Reopen Poll' => 'Reabrir votação',
  'Reset my vote' => 'Mudar o meu voto',
  'Vote' => 'Voto',
  'and {count} more vote for this.' => 'e {count} votaram para esta opção.',
  'votes' => 'votos',
);
