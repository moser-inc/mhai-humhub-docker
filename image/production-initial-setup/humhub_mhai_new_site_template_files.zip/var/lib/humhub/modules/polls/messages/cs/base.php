<?php
return array (
  'Allows the user to create polls' => 'Povolit uživateli vytvářet ankety',
  'Allows to start polls.' => 'Povolit vytváření anket.',
  'Answers' => 'Odpovědi',
  'At least one answer is required' => 'Je vyžadována alespoň jedna odpověď',
  'Cancel' => 'Zrušit',
  'Create poll' => 'Vytvořit anketu',
  'Polls' => 'Ankety',
  'Save' => 'Uložit',
  '{n,plural,=1{# {htmlTagBegin}vote{htmlTagEnd}}other{# {htmlTagBegin}votes{htmlTagEnd}}}' => '',
);
