<?php
return array (
  '<strong>Note:</strong> The result is hidden until the poll is closed by a moderator.' => '<strong>Huomaa:</strong> tulos on piilotettu, kunnes tekijä sulkee kyselyn.',
  'Anonymous' => 'Anonyymi',
  'Closed' => 'Suljettu',
  'Complete Poll' => 'Sulje kysely',
  'Reopen Poll' => 'Avaa kysely uudeleen',
  'Reset my vote' => 'Poista vastaukseni',
  'Vote' => 'Vastaa',
  'and {count} more vote for this.' => 'ja {count} muuta vastasivat tähän.',
  'votes' => 'Vastaukset',
);
