<?php
return array (
  '<strong>Note:</strong> The result is hidden until the poll is closed by a moderator.' => '<strong>注意：</strong> 結果はアンケートが終了するまで表示されません。',
  'Anonymous' => '匿名',
  'Closed' => '終了',
  'Complete Poll' => 'アンケートを終了',
  'Reopen Poll' => 'アンケートを再開',
  'Reset my vote' => '私の投票をリセット',
  'Vote' => '投票',
  'and {count} more vote for this.' => '他 {count} 人が投票',
  'votes' => '票',
);
