<?php

return [
    'Description' => 'Περιγραφή',
    'Answers' => '',
    'Multiple answers per user' => '',
    'Please specify at least {min} answers!' => '',
    'Poll' => '',
    'Question' => '',
];
