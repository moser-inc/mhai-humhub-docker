<?php
return array (
  'Allows the user to create polls' => 'Permite al usuario crear encuestas.',
  'Allows to start polls.' => 'Permite iniciar encuestas.',
  'Answers' => 'Respuestas',
  'At least one answer is required' => 'Se requiere al menos una respuesta',
  'Cancel' => 'Cancelar',
  'Create poll' => 'Crear encuesta',
  'Polls' => 'Votaciones',
  'Save' => 'Guardar',
  '{n,plural,=1{# {htmlTagBegin}vote{htmlTagEnd}}other{# {htmlTagBegin}votes{htmlTagEnd}}}' => '{n,plural,=1{# {htmlTagBegin}vote{htmlTagEnd}}other{# {htmlTagBegin}votes{htmlTagEnd}}}',
);
