<?php
return array (
  'Polls' => 'الاستطلاعات',
  'Whenever someone participates in a poll.' => 'عندما يشارك شخص ما في استطلاع رأي.',
);
