<?php
return array (
  'Add answer...' => 'Pievieno atbildi...',
  'Anonymous Votes?' => 'Anonīmi balsojumi?',
  'Description' => 'Apraksts',
  'Display answers in random order?' => 'Parādīt atbildes jauktā kārtībā?',
  'Edit answer (empty answers will be removed)...' => 'Labot atbildi (tukšie balsojumi tiks dzēsti)...',
  'Edit your poll question...' => 'Labot savu aptaujas jautājumu...',
  'Hide results until poll is closed?' => '',
  'Question' => 'Jautājums',
);
