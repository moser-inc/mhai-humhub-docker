<?php
return array (
  'Polls' => 'Apklausos',
  'Whenever someone participates in a poll.' => '',
);
