<?php
return array (
  'Add answer...' => 'Aggiungi risposta...',
  'Anonymous Votes?' => 'Voti anonimi?',
  'Description' => 'Descrizione',
  'Display answers in random order?' => 'Mostra le risposte in ordine casuale?',
  'Edit answer (empty answers will be removed)...' => 'Modifica risposta (le risposte vuote saranno rimosse)...',
  'Edit your poll question...' => 'Modifica la domanda del tuo sondaggio...',
  'Hide results until poll is closed?' => 'Vuoi nascondere i rosultati quando il sondaggio è chiuso? ',
  'Question' => 'Domanda',
);
