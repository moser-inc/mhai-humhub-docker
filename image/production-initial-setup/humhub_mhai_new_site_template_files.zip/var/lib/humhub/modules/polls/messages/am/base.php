<?php

return [
    'Cancel' => 'ይቅር',
    'Save' => 'አስቀምጥ',
    'Allows the user to create polls' => '',
    'Allows to start polls.' => '',
    'Answers' => '',
    'At least one answer is required' => '',
    'Create poll' => '',
    'Polls' => '',
    '{n,plural,=1{# {htmlTagBegin}vote{htmlTagEnd}}other{# {htmlTagBegin}votes{htmlTagEnd}}}' => '',
];
