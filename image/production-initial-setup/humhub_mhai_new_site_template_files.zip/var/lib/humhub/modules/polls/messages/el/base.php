<?php

return [
    'Cancel' => 'Ακύρωση',
    'Polls' => 'Ψηφοφορίες',
    'Save' => 'Αποθήκευση',
    'Allows the user to create polls' => '',
    'Allows to start polls.' => '',
    'Answers' => '',
    'At least one answer is required' => '',
    'Create poll' => '',
    '{n,plural,=1{# {htmlTagBegin}vote{htmlTagEnd}}other{# {htmlTagBegin}votes{htmlTagEnd}}}' => '',
];
