<?php
return array (
  'Again? ;Weary;' => 'Mais uma vez? ;Weary;',
  'Club A Steakhouse' => 'Club A Steakhouse',
  'Location of the next meeting' => 'Local da próxima reunião',
  'Pisillo Italian Panini' => 'Pisillo Italian Panini',
  'Right now, we are in the planning stages for our next meetup and we would like to know from you, where you would like to go?' => 'Agora, estamos nos estágios de planejamento para nossa próxima reunião e gostaríamos de saber de você, onde você gostaria de ir?',
  'To Daniel' => 'Para Daniel',
  'Why don\'t we go to Bemelmans Bar?' => 'Por que não vamos ao Bemelmans Bar?',
);
