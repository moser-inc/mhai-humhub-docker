<?php
return array (
  'Add answer...' => 'Lägg till svar...',
  'Anonymous Votes?' => 'Anonyma röster?',
  'Description' => 'Beskrivning',
  'Display answers in random order?' => 'Visa svar i slumpmässig ordning?',
  'Edit answer (empty answers will be removed)...' => 'Redigera svar (tomma svar kommer att tas bort)...',
  'Edit your poll question...' => 'Redigera din enkät fråga',
  'Hide results until poll is closed?' => 'Dölj resultat tills enkäten är avslutad?',
  'Question' => 'Fråga',
);
