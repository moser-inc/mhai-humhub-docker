<?php
return array (
  '<strong>Note:</strong> The result is hidden until the poll is closed by a moderator.' => '<strong>Poznámka:</strong> Výsledek je skrytý, dokud hlasování neuzavře moderátor.',
  'Anonymous' => 'Anonym',
  'Closed' => 'Uzavřeno',
  'Complete Poll' => 'Dokončit anketu',
  'Reopen Poll' => 'Znovu otevřít anketu',
  'Reset my vote' => 'Zrušit mé hlasování',
  'Vote' => 'Hlasovat',
  'and {count} more vote for this.' => 'a dalších {count} lidí pro to hlasovalo.',
  'votes' => 'hlasů',
);
