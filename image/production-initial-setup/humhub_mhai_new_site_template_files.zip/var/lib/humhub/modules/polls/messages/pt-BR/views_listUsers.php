<?php
return array (
  'User who vote this' => 'Usuário que vota nesta',
);
