<?php
return array (
  '<strong>Note:</strong> The result is hidden until the poll is closed by a moderator.' => '<strong>Ghi chú:</strong> Kết quả được ẩn cho tới khi phiên biểu quyết được đóng bởi điều hành viên.',
  'Anonymous' => 'Vô danh',
  'Closed' => 'Đóng',
  'Complete Poll' => 'Hoàn thành biểu quyết',
  'Reopen Poll' => 'Mở lại biểu quyết',
  'Reset my vote' => 'Đặt lại phiếu của tôi',
  'Vote' => 'Bỏ phiếu',
  'and {count} more vote for this.' => 'và  thêm {count} biểu quyết cho điều này.',
  'votes' => 'bỏ phiếu',
);
