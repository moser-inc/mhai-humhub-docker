<?php
return array (
  'Allows the user to create polls' => 'Låter användaren skapa undersökningar',
  'Allows to start polls.' => 'Tillåtelse att starta undersökningar.',
  'Answers' => 'Svar',
  'At least one answer is required' => 'Minst ett svar krävs',
  'Cancel' => 'Avbryt',
  'Create poll' => 'Skapa undersökning',
  'Polls' => 'Enkät',
  'Save' => 'Spara',
  '{n,plural,=1{# {htmlTagBegin}vote{htmlTagEnd}}other{# {htmlTagBegin}votes{htmlTagEnd}}}' => '{n,plural,=1{# {htmlTagBegin}vote{htmlTagEnd}}other{# {htmlTagBegin}votes{htmlTagEnd}}}',
);
