<?php
return array (
  'Again? ;Weary;' => 'また？ ;疲れた;',
  'Club A Steakhouse' => 'クラブAステーキハウス',
  'Location of the next meeting' => '次の会議の場所',
  'Pisillo Italian Panini' => 'ピシーロイタリアンパニーニ',
  'Right now, we are in the planning stages for our next meetup and we would like to know from you, where you would like to go?' => '現在、次のミートアップの計画段階にあります。どこに行きたいですか？',
  'To Daniel' => 'ダニエルへ',
  'Why don\'t we go to Bemelmans Bar?' => 'ベメルマンズバーに行ってみませんか？',
);
