<?php
return array (
  'Add answer...' => 'Vložit odpověď...',
  'Anonymous Votes?' => 'Anonymní hlasování?',
  'Description' => 'Popis',
  'Display answers in random order?' => 'Zobrazit odpovědi náhodně?',
  'Edit answer (empty answers will be removed)...' => 'Upravit odpovědi (prázdné odpovědi budou smazány)...',
  'Edit your poll question...' => 'Upravit otázku Vaší ankety...',
  'Hide results until poll is closed?' => 'Skrýt výsledky, dokud nebude hlasování uzavřeno?',
  'Question' => 'Otázka',
);
