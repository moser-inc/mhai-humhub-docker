<?php
return array (
  'Allows the user to create polls' => 'Erabiltzaileari inkestak sortzeko aukera ematen dio',
  'Allows to start polls.' => 'Inkestak hasteko aukera ematen du.',
  'Answers' => 'Galderak',
  'At least one answer is required' => 'Gutxienez erantzun bat behar da',
  'Cancel' => 'Utzi bertan behera',
  'Create poll' => 'Sortu inkesta',
  'Polls' => 'Inkestak',
  'Save' => 'Gorde',
  '{n,plural,=1{# {htmlTagBegin}vote{htmlTagEnd}}other{# {htmlTagBegin}votes{htmlTagEnd}}}' => '{n,plural,=1{# {htmlTagBegin}vote{htmlTagEnd}}other{# {htmlTagBegin}votes{htmlTagEnd}}}',
);
