<?php
return array (
  '<b>There are no polls yet!</b>' => '<b>Encara no hi ha enquestes!</b>',
  '<b>There are no polls yet!</b><br>Be the first and create one...' => '<b>Encara no hi ha enquestes!</b><br>Sigues el primer en crear una...',
  'Asked by me' => 'Preguntat per mi',
  'No answered yet' => 'No contestat',
  'Only private polls' => 'Només enquestes privades',
  'Only public polls' => 'Només enquestes públiques',
);
