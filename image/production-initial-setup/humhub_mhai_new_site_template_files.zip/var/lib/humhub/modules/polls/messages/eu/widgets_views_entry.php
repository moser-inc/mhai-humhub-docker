<?php
return array (
  '<strong>Note:</strong> The result is hidden until the poll is closed by a moderator.' => '<strong>Oharra:</strong> emaitza ezkutatuta egongo da moderatzaile batek inkesta itxi arte.',
  'Anonymous' => 'Anonimoa',
  'Closed' => 'Itxita',
  'Complete Poll' => 'Inkesta osoa',
  'Reopen Poll' => 'Ireki berriro inkesta',
  'Reset my vote' => 'Ezabatu nire botua',
  'Vote' => 'Bozkatu',
  'and {count} more vote for this.' => 'eta {count} boto gehiago honen alde.',
  'votes' => 'Botuak',
);
