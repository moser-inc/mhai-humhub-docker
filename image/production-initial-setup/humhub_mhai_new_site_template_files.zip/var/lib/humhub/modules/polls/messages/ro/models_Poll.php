<?php

return [
    'Description' => 'Descriere',
    'Answers' => '',
    'Multiple answers per user' => '',
    'Please specify at least {min} answers!' => '',
    'Poll' => '',
    'Question' => '',
];
